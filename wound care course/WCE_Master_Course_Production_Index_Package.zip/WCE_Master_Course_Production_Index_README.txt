Wound Care Essentials — Master Course Production Index

Files included:
1. WCE_Master_Course_Production_Index.xlsx
2. This README

Workbook tabs:
- Overview
- Lesson Index
- Deliverables Matrix
- File Naming
- Status Tracker

Purpose:
This workbook is the course-level control sheet for the full 6-lesson wound care production workflow.
Use it to track lesson objectives, package filenames, deliverables, and production status.

Recommended next step:
Open the Lesson Index tab first, then use the Status Tracker to move lesson-by-lesson through script lock, asset approval, voiceover, edit, review, and final approval.
